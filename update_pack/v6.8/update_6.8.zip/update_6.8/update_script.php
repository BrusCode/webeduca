<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();

// Add Column sub_category_thumbnail 
$sub_category_thumbnail = array(
    'sub_category_thumbnail' => array(
        'type' => 'varchar',
        'constraint' => 255,
        'default' => NULL,
        'null' => TRUE,
        'collation' => 'utf8_unicode_ci'
    )
);
$CI->dbforge->add_column('category', $sub_category_thumbnail);

// update VERSION NUMBER INSIDE SETTINGS TABLE
$settings_data = array('value' => '6.8');
$CI->db->where('key', 'version');
$CI->db->update('settings', $settings_data);